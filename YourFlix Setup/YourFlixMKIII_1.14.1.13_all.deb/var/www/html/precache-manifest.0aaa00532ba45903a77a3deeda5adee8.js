self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1daa1a28041857a4c088f65c1505c4e1",
    "url": "/index.html"
  },
  {
    "revision": "ef43548f1c7f40c1eb57",
    "url": "/static/css/main.2efa9b5c.chunk.css"
  },
  {
    "revision": "361377a9f353756dca6d",
    "url": "/static/js/2.873464a2.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.873464a2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ef43548f1c7f40c1eb57",
    "url": "/static/js/main.80329f4d.chunk.js"
  },
  {
    "revision": "16c9a748f08fea276208",
    "url": "/static/js/runtime-main.a5d36475.js"
  },
  {
    "revision": "b7aa267e93c634d5dc6b3efa0e033245",
    "url": "/static/media/ExpandButton.b7aa267e.svg"
  },
  {
    "revision": "d9dd7ebeccd54c115b4f63816f813f9b",
    "url": "/static/media/Left-Point Arrow.d9dd7ebe.svg"
  },
  {
    "revision": "9617fc8fdb7fdc25d0ab6f128833471f",
    "url": "/static/media/LeftArrow.9617fc8f.svg"
  },
  {
    "revision": "c01c689e35379bf4e7555198fc4e9308",
    "url": "/static/media/PauseButton.c01c689e.svg"
  },
  {
    "revision": "d8deac5026fbeb5b911f0515d20ce4a6",
    "url": "/static/media/PlayButton.d8deac50.svg"
  },
  {
    "revision": "e0b3e6f57af6eba9e72c4a994b97a511",
    "url": "/static/media/RightArrow.e0b3e6f5.svg"
  },
  {
    "revision": "703dffd2444b251c6ab2b48f70551772",
    "url": "/static/media/SearchIcon.703dffd2.svg"
  },
  {
    "revision": "bdbcf221274117f5159d45f8ff340530",
    "url": "/static/media/YourFlix.bdbcf221.svg"
  },
  {
    "revision": "4746b67254fb1ea59d969d1c4e03dc23",
    "url": "/static/media/yf-PlayButton.4746b672.svg"
  }
]);